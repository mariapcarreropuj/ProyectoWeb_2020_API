package com.puj.admincenter.dto

data class IdResponseDto(
    val id: Long
)
