package com.puj.admincenter.dto.login

data class TokenDto (
    val token: String,
    val userId: Int
)