package com.puj.admincenter.dto.login

data class LoginDto (
    val username: String,
    val password: String
)